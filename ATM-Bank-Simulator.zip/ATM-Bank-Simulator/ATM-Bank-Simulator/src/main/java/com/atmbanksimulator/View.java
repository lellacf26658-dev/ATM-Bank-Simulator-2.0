package com.atmbanksimulator;

import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class View {

    Controller controller;
    UIModel    uiModel;

    private Label     messageLabel;
    private TextField inputField;
    private TextArea  resultArea;
    private Label     accountTypeBadge;
    private Label     stateLabel;
    private Label     modeToggleBtn;

    private StackPane root;
    private HBox      mainContent;
    private VBox      atmBody;
    private VBox      funcPanel;

    private Circle blob1, blob2, blob3;
    private AnimationTimer meshTimer;
    private long meshStartNano = -1;

    private StackPane welcomeOverlay;
    private StackPane goodbyeOverlay;
    private Scene     scene;
    private boolean goodbyeShowing = false;
    private boolean isDarkMode = true;

    private static final String D_BASE   = "#13181B";
    private static final String D_ACCENT = "#003A6C";
    private static final String D_PANEL  = "rgba(19,24,27,0.92)";
    private static final String D_BORDER = "rgba(142,200,245,0.20)";
    private static final String D_TXT1   = "#8EC8F5";
    private static final String D_TXT2   = "#C0DCF0";
    private static final String D_SCREEN = "rgba(2,5,14,0.98)";

    private static final String L_BASE   = "#CCD5DA";
    private static final String L_ACCENT = "#003A6C";
    private static final String L_PANEL  = "rgba(240,238,235,0.94)";
    private static final String L_BORDER = "rgba(0,58,108,0.50)";
    private static final String L_TXT1   = "#0D1E2C";
    private static final String L_TXT2   = "#003A6C";
    private static final String L_SCREEN = "rgba(0,58,108,0.10)";

    private static final String AMBER = "#FFBF65";
    private static final String CORAL = "#FD8973";

    private String bg()       { return isDarkMode ? D_BASE   : L_BASE;   }
    private String accent()   { return isDarkMode ? D_ACCENT : L_ACCENT; }
    private String panelBg()  { return isDarkMode ? D_PANEL  : L_PANEL;  }
    private String border()   { return isDarkMode ? D_BORDER : L_BORDER; }
    private String txt1()     { return isDarkMode ? D_TXT1   : L_TXT1;   }
    private String txt2()     { return isDarkMode ? D_TXT2   : L_TXT2;   }
    private String screenBg() { return D_SCREEN; }

    private String glassPanel() {
        return "-fx-background-color: " + panelBg() + ";" +
                "-fx-border-color: " + border() + ";" +
                "-fx-border-width: 1.5;" +
                "-fx-background-radius: 22;" +
                "-fx-border-radius: 22;";
    }

    public void start(Stage window) {
        root = new StackPane();
        root.setStyle("-fx-background-color: " + bg() + ";");

        Pane bgPane = buildMeshBackground();
        root.getChildren().add(bgPane);

        mainContent = buildATMMachine();
        mainContent.setAlignment(Pos.CENTER);
        mainContent.setOpacity(0);
        mainContent.setMouseTransparent(true);
        root.getChildren().add(mainContent);

        welcomeOverlay = buildSplashOverlay("Welcome to FIN Bank ATM", "Press ENTER to continue");
        root.getChildren().add(welcomeOverlay);

        goodbyeOverlay = buildSplashOverlay("Thank you for choosing FIN Bank", "");
        goodbyeOverlay.setOpacity(0);
        goodbyeOverlay.setMouseTransparent(true);
        root.getChildren().add(goodbyeOverlay);

        scene = new Scene(root, 960, 720);
        scene.setFill(Color.web(bg()));

        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                transitionToMain();
            }
        });

        window.setTitle("FIN Bank ATM Simulator");
        window.setScene(scene);
        window.setMinWidth(830);
        window.setMinHeight(650);
        window.show();

        welcomeOverlay.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(900), welcomeOverlay);
        ft.setFromValue(0.0);
        ft.setToValue(1.0);
        ft.play();
    }

    private StackPane buildSplashOverlay(String title, String subtitle) {
        StackPane overlay = new StackPane();
        overlay.setStyle("-fx-background-color: transparent;");

        VBox card = new VBox(20);
        card.setAlignment(Pos.CENTER);
        card.setStyle(
                "-fx-background-color: " + panelBg() + ";" +
                        "-fx-border-color: " + border() + ";" +
                        "-fx-border-width: 1.5;" +
                        "-fx-background-radius: 24;" +
                        "-fx-border-radius: 24;" +
                        "-fx-padding: 55 80 55 80;"
        );
        card.setMaxWidth(520);

        DropShadow cardShadow = new DropShadow();
        cardShadow.setColor(Color.web(AMBER, 0.25));
        cardShadow.setRadius(40);
        card.setEffect(cardShadow);

        Label bankTag = new Label("FIN BANK");
        bankTag.setStyle(
                "-fx-text-fill: " + AMBER + ";" +
                        "-fx-font-family: Arial;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-letter-spacing: 3;"
        );

        Region divider = new Region();
        divider.setStyle("-fx-background-color: rgba(255,191,101,0.35);");
        divider.setMinHeight(1);
        divider.setMaxWidth(200);

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-text-fill: " + D_TXT1 + ";" +
                        "-fx-font-family: Arial;" +
                        "-fx-font-size: 24px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-wrap-text: true;" +
                        "-fx-text-alignment: center;"
        );
        titleLabel.setAlignment(Pos.CENTER);
        titleLabel.setMaxWidth(400);

        card.getChildren().addAll(bankTag, divider, titleLabel);

        if (!subtitle.isEmpty()) {
            Label subLabel = new Label(subtitle);
            subLabel.setStyle(
                    "-fx-text-fill: " + D_TXT2 + ";" +
                            "-fx-font-family: 'Courier New';" +
                            "-fx-font-size: 13px;" +
                            "-fx-wrap-text: true;" +
                            "-fx-text-alignment: center;"
            );
            subLabel.setAlignment(Pos.CENTER);

            FadeTransition pulse = new FadeTransition(Duration.millis(900), subLabel);
            pulse.setFromValue(0.4);
            pulse.setToValue(1.0);
            pulse.setAutoReverse(true);
            pulse.setCycleCount(Animation.INDEFINITE);
            pulse.play();

            card.getChildren().add(subLabel);
        }

        overlay.getChildren().add(card);
        return overlay;
    }

    private void transitionToMain() {
        if (welcomeOverlay.getOpacity() < 0.1) return;

        FadeTransition fadeOut = new FadeTransition(Duration.millis(500), welcomeOverlay);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> {
            welcomeOverlay.setMouseTransparent(true);
            mainContent.setMouseTransparent(false);
        });

        FadeTransition fadeIn = new FadeTransition(Duration.millis(600), mainContent);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);

        fadeOut.play();
        fadeIn.play();
    }

    private void showGoodbyeScreen() {
        goodbyeShowing = true;

        goodbyeOverlay.setMouseTransparent(false);
        FadeTransition fadeInGoodbye = new FadeTransition(Duration.millis(600), goodbyeOverlay);
        fadeInGoodbye.setFromValue(0.0);
        fadeInGoodbye.setToValue(1.0);

        FadeTransition fadeOutMain = new FadeTransition(Duration.millis(500), mainContent);
        fadeOutMain.setToValue(0.0);

        PauseTransition hold = new PauseTransition(Duration.seconds(5));

        hold.setOnFinished(e -> {
            uiModel.initialise();

            FadeTransition fadeOutGoodbye = new FadeTransition(Duration.millis(500), goodbyeOverlay);
            fadeOutGoodbye.setToValue(0.0);
            fadeOutGoodbye.setOnFinished(ev -> {
                goodbyeOverlay.setMouseTransparent(true);
                goodbyeShowing = false;
            });

            welcomeOverlay.setOpacity(0);
            welcomeOverlay.setMouseTransparent(false);
            FadeTransition fadeInWelcome = new FadeTransition(Duration.millis(700), welcomeOverlay);
            fadeInWelcome.setFromValue(0.0);
            fadeInWelcome.setToValue(1.0);

            fadeOutGoodbye.play();
            fadeInWelcome.play();
        });

        fadeInGoodbye.setOnFinished(e -> hold.play());
        fadeInGoodbye.play();
        fadeOutMain.play();
    }

    private Pane buildMeshBackground() {
        Pane pane = new Pane();
        pane.setMouseTransparent(true);
        pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        blob1 = makeBlob(480, 200, 370, AMBER, 0.48);
        blob2 = makeBlob(180, 540, 330, CORAL, 0.42);
        blob3 = makeBlob(740, 530, 350, D_ACCENT, isDarkMode ? 0.58 : 0.50);

        pane.getChildren().addAll(blob1, blob2, blob3);

        meshStartNano = -1;
        meshTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (meshStartNano < 0) meshStartNano = now;
                double t = (now - meshStartNano) / 1_000_000_000.0;

                blob1.setCenterX(480 + Math.sin(t * 0.40) * 240);
                blob1.setCenterY(200 + Math.cos(t * 0.28) * 160);
                blob2.setCenterX(175 + Math.cos(t * 0.35) * 200);
                blob2.setCenterY(540 + Math.sin(t * 0.50) * 145);
                blob3.setCenterX(740 + Math.sin(t * 0.30) * 160);
                blob3.setCenterY(530 + Math.cos(t * 0.43) * 180);
            }
        };
        meshTimer.start();

        return pane;
    }

    private Circle makeBlob(double cx, double cy, double r, String hex, double alpha) {
        Circle c = new Circle(cx, cy, r);
        Color col = Color.web(hex, alpha);
        c.setFill(new RadialGradient(0, 0, 0.5, 0.5, 0.5, true,
                CycleMethod.NO_CYCLE,
                new Stop(0.0, col),
                new Stop(1.0, Color.TRANSPARENT)));
        c.setEffect(new GaussianBlur(55));
        return c;
    }

    private HBox buildATMMachine() {
        HBox hbox = new HBox(14);
        hbox.setAlignment(Pos.CENTER);
        hbox.setPadding(new Insets(28));

        atmBody = buildATMBody();
        funcPanel = buildFuncPanel();
        hbox.getChildren().addAll(atmBody, funcPanel);
        return hbox;
    }

    private VBox buildATMBody() {
        VBox body = new VBox(12);
        body.setStyle(glassPanel());
        body.setPadding(new Insets(20));
        body.setMinWidth(510);
        body.setMaxWidth(532);

        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.web(AMBER, 0.18));
        shadow.setRadius(32);
        body.setEffect(shadow);

        body.getChildren().addAll(buildHeader(), buildScreen(), buildNumpad());
        return body;
    }

    private HBox buildHeader() {
        HBox row = new HBox();
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(0, 0, 10, 0));
        row.setStyle("-fx-border-color: transparent transparent " + border() + " transparent;-fx-border-width: 0 0 1 0;");

        Text name = new Text("FIN BANK");
        name.setFont(Font.font("Arial", FontWeight.BOLD, 19));
        name.setFill(Color.web(AMBER));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        accountTypeBadge = new Label();
        accountTypeBadge.setStyle(
                "-fx-background-color: rgba(255,191,101,0.13);" +
                        "-fx-text-fill: " + AMBER + ";" +
                        "-fx-font-size: 11px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 5;" +
                        "-fx-border-color: rgba(255,191,101,0.45);" +
                        "-fx-border-radius: 5;" +
                        "-fx-border-width: 1;" +
                        "-fx-padding: 3 8 3 8;"
        );
        accountTypeBadge.setVisible(false);

        modeToggleBtn = new Label(isDarkMode ? "LIGHT MODE" : "DARK MODE");
        String tBase = "-fx-text-fill: " + txt2() + ";-fx-font-size: 10px;-fx-font-weight: bold;-fx-cursor: hand;-fx-padding: 3 8 3 8;-fx-background-color: rgba(255,255,255,0.05);-fx-background-radius: 5;-fx-border-radius: 5;-fx-border-color: " + border() + ";-fx-border-width: 1;";
        String tHover = "-fx-text-fill: " + AMBER + ";-fx-font-size: 10px;-fx-font-weight: bold;-fx-cursor: hand;-fx-padding: 3 8 3 8;-fx-background-color: rgba(255,191,101,0.14);-fx-background-radius: 5;-fx-border-radius: 5;-fx-border-color: rgba(255,191,101,0.50);-fx-border-width: 1;";
        modeToggleBtn.setStyle(tBase);
        modeToggleBtn.setOnMouseEntered(e -> modeToggleBtn.setStyle(tHover));
        modeToggleBtn.setOnMouseExited(e -> modeToggleBtn.setStyle(tBase));
        modeToggleBtn.setOnMouseClicked(e -> toggleTheme());

        Region gap = new Region();
        gap.setMinWidth(8);

        row.getChildren().addAll(name, spacer, accountTypeBadge, gap, modeToggleBtn);
        return row;
    }

    private VBox buildScreen() {
        VBox screen = new VBox(8);
        screen.setStyle(
                "-fx-background-color: " + screenBg() + ";" +
                        "-fx-background-radius: 14;" +
                        "-fx-border-radius: 14;" +
                        "-fx-border-color: rgba(255,191,101,0.20);" +
                        "-fx-border-width: 1.5;" +
                        "-fx-padding: 14;"
        );
        screen.setMinHeight(222);

        messageLabel = new Label("Initialising...");
        messageLabel.setStyle(msgStyle(txt1()));
        messageLabel.setMaxWidth(Double.MAX_VALUE);

        Region div = new Region();
        div.setStyle("-fx-background-color: rgba(255,191,101,0.16);");
        div.setMinHeight(1);

        inputField = new TextField();
        inputField.setEditable(false);
        inputField.setStyle(inputStyle());
        inputField.setMaxWidth(Double.MAX_VALUE);
        inputField.setPromptText("Enter number...");

        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setWrapText(true);
        resultArea.setStyle(resultStyle());
        resultArea.setPrefHeight(120);
        resultArea.setMaxHeight(140);

        stateLabel = new Label("State: account_no");
        stateLabel.setStyle("-fx-text-fill: rgba(140,150,160,0.42);-fx-font-size: 9px;-fx-font-family: 'Courier New';");

        screen.getChildren().addAll(messageLabel, div, inputField, resultArea, stateLabel);
        return screen;
    }

    private GridPane buildNumpad() {
        GridPane pad = new GridPane();
        pad.setHgap(8);
        pad.setVgap(8);
        pad.setPadding(new Insets(10, 0, 0, 0));

        pad.add(numBtn("1"), 0, 0);
        pad.add(numBtn("2"), 1, 0);
        pad.add(numBtn("3"), 2, 0);
        pad.add(numBtn("4"), 0, 1);
        pad.add(numBtn("5"), 1, 1);
        pad.add(numBtn("6"), 2, 1);
        pad.add(numBtn("7"), 0, 2);
        pad.add(numBtn("8"), 1, 2);
        pad.add(numBtn("9"), 2, 2);
        pad.add(clrBtn(), 0, 3);
        pad.add(numBtn("0"), 1, 3);
        pad.add(entBtn(), 2, 3);
        return pad;
    }

    private VBox buildFuncPanel() {
        VBox panel = new VBox(8);
        panel.setStyle(glassPanel());
        panel.setPadding(new Insets(20));
        panel.setMinWidth(212);
        panel.setMaxWidth(222);

        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.web(CORAL, 0.14));
        shadow.setRadius(24);
        panel.setEffect(shadow);

        Label title = new Label("MENU");
        title.setStyle("-fx-text-fill: rgba(190,200,210,0.45);-fx-font-size: 10px;-fx-font-weight: bold;-fx-padding: 0 0 4 4;");

        Region topDiv = new Region();
        topDiv.setStyle("-fx-background-color: " + border() + ";");
        topDiv.setMinHeight(1);

        Button btnBal = funcBtn("BAL    Balance", "Bal");
        Button btnWD = funcBtn("W/D    Withdraw", "W/D");
        Button btnDep = funcBtn("DEP    Deposit", "Dep");
        Button btnTrf = funcBtn("TRF    Transfer", "Trf");
        Button btnChP = funcBtn("ChP    Chg Password", "ChP");
        Button btnStmt = funcBtn("STMT   Statement", "Stmt");
        Button btnCur = funcBtn("CUR    Currency", "Cur");
        Button btnInt = funcBtn("INT    Interest", "Int");
        Button btnNew = funcBtn("NEW    New Account", "NewAcc");

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Region botDiv = new Region();
        botDiv.setStyle("-fx-background-color: rgba(253,137,115,0.22);");
        botDiv.setMinHeight(1);

        Button btnFin = logoutBtn("FIN    Log Out", "Fin");

        panel.getChildren().addAll(
                title, topDiv,
                btnBal, btnWD, btnDep, btnTrf, btnChP,
                btnStmt, btnCur, btnInt, btnNew,
                spacer, botDiv, btnFin
        );
        return panel;
    }

    private Button numBtn(String d) {
        Button b = new Button(d);
        b.setStyle(numBase());
        b.setOnMouseEntered(e -> b.setStyle(numHover()));
        b.setOnMouseExited(e -> b.setStyle(numBase()));
        b.setOnAction(e -> controller.process(d));
        return b;
    }

    private String numBase() {
        String bg = isDarkMode ? "rgba(255,255,255,0.12)" : "rgba(0,58,108,0.18)";
        return "-fx-background-color:" + bg + ";-fx-text-fill:" + txt1() + ";-fx-font-size:17px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:" + border() + ";-fx-border-width:1.2;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
    }

    private String numHover() {
        String txt = isDarkMode ? "#F0EEEB" : "#0D1E2C";
        return "-fx-background-color:rgba(255,191,101,0.38);-fx-text-fill:" + txt + ";-fx-font-size:17px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:rgba(255,191,101,0.75);-fx-border-width:1.5;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
    }

    private Button clrBtn() {
        String base = "-fx-background-color:rgba(255,191,101,0.09);-fx-text-fill:" + AMBER + ";-fx-font-size:14px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:rgba(255,191,101,0.32);-fx-border-width:1;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
        String hover = "-fx-background-color:rgba(255,191,101,0.26);-fx-text-fill:#13181B;-fx-font-size:14px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:rgba(255,191,101,0.78);-fx-border-width:1.5;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
        Button b = new Button("CLR");
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(hover));
        b.setOnMouseExited(e -> b.setStyle(base));
        b.setOnAction(e -> controller.process("CLR"));
        return b;
    }

    private Button entBtn() {
        String base = "-fx-background-color:rgba(253,137,115,0.11);-fx-text-fill:" + CORAL + ";-fx-font-size:14px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:rgba(253,137,115,0.38);-fx-border-width:1;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
        String hover = "-fx-background-color:rgba(253,137,115,0.30);-fx-text-fill:white;-fx-font-size:14px;-fx-font-weight:bold;-fx-background-radius:12;-fx-border-radius:12;-fx-border-color:rgba(253,137,115,0.82);-fx-border-width:1.5;-fx-cursor:hand;-fx-min-width:62px;-fx-min-height:52px;";
        Button b = new Button("ENT");
        b.setStyle(base);
        b.setOnMouseEntered(e -> b.setStyle(hover));
        b.setOnMouseExited(e -> b.setStyle(base));
        b.setOnAction(e -> controller.process("Ent"));
        return b;
    }

    private Button funcBtn(String label, String action) {
        Button btn = new Button(label);
        btn.setStyle(funcBase());
        btn.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
        btn.setMaxWidth(Double.MAX_VALUE);

        ScaleTransition up = new ScaleTransition(Duration.millis(125), btn);
        up.setToX(1.04);
        up.setToY(1.04);
        ScaleTransition down = new ScaleTransition(Duration.millis(125), btn);
        down.setToX(1.0);
        down.setToY(1.0);

        final double[] ph = {0.0};

        Timeline holo = new Timeline(new KeyFrame(Duration.millis(38), e -> {
            ph[0] += 0.045;
            double s = (Math.sin(ph[0]) + 1.0) / 2.0;
            double c = (Math.cos(ph[0] * 0.72) + 1.0) / 2.0;

            String grad = String.format(
                    "linear-gradient(from %.0f%% 0%% to %.0f%% 100%%, rgba(255,191,101,%.2f), rgba(253,137,115,%.2f), rgba(255,191,101,%.2f))",
                    s * 100, (1.0 - c) * 100, 0.15 + s * 0.15, 0.18 + c * 0.16, 0.12 + s * 0.12
            );

            DropShadow glow = new DropShadow();
            double rr = 0.85 + 0.15 * Math.sin(ph[0]);
            double gg = 0.45 + 0.28 * Math.cos(ph[0]);
            glow.setColor(Color.color(rr, gg, 0.35, 0.55));
            glow.setRadius(13);
            glow.setSpread(0.07);
            btn.setEffect(glow);

            btn.setStyle("-fx-background-color: " + grad + ";-fx-text-fill: " + txt1() + ";-fx-font-size: 12px;-fx-font-weight: bold;-fx-background-radius: 11;-fx-border-radius: 11;-fx-border-color: rgba(253,137,115,0.68);-fx-border-width: 1.5;-fx-cursor: hand;-fx-min-height: 40px;-fx-padding: 0 0 0 12;-fx-alignment: CENTER_LEFT;");
        }));
        holo.setCycleCount(Animation.INDEFINITE);

        btn.setOnMouseEntered(e -> { ph[0] = 0; up.playFromStart(); holo.play(); });
        btn.setOnMouseExited(e -> { holo.stop(); down.playFromStart(); btn.setStyle(funcBase()); btn.setEffect(null); });
        btn.setOnAction(e -> controller.process(action));
        return btn;
    }

    private Button logoutBtn(String label, String action) {
        String base = "-fx-background-color:rgba(253,137,115,0.09);-fx-text-fill:" + CORAL + ";-fx-font-size:12px;-fx-font-weight:bold;-fx-background-radius:11;-fx-border-radius:11;-fx-border-color:rgba(253,137,115,0.32);-fx-border-width:1;-fx-cursor:hand;-fx-min-height:40px;-fx-padding:0 0 0 12;-fx-alignment:CENTER_LEFT;";
        String hover = "-fx-background-color:rgba(253,137,115,0.26);-fx-text-fill:white;-fx-font-size:12px;-fx-font-weight:bold;-fx-background-radius:11;-fx-border-radius:11;-fx-border-color:rgba(253,137,115,0.82);-fx-border-width:1.5;-fx-cursor:hand;-fx-min-height:40px;-fx-padding:0 0 0 12;-fx-alignment:CENTER_LEFT;";
        Button btn = new Button(label);
        btn.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setStyle(base);

        ScaleTransition up = new ScaleTransition(Duration.millis(125), btn);
        up.setToX(1.03);
        up.setToY(1.03);
        ScaleTransition down = new ScaleTransition(Duration.millis(125), btn);
        down.setToX(1.0);
        down.setToY(1.0);

        btn.setOnMouseEntered(e -> { up.playFromStart(); btn.setStyle(hover); });
        btn.setOnMouseExited(e -> { down.playFromStart(); btn.setStyle(base); btn.setEffect(null); });
        btn.setOnAction(e -> controller.process(action));
        return btn;
    }

    private String funcBase() {
        String bg = isDarkMode ? "rgba(255,255,255,0.08)" : "rgba(0,58,108,0.16)";
        return "-fx-background-color:" + bg + ";-fx-text-fill:" + txt1() + ";-fx-font-size:12px;-fx-font-weight:bold;-fx-background-radius:11;-fx-border-radius:11;-fx-border-color:" + border() + ";-fx-border-width:1.2;-fx-cursor:hand;-fx-min-height:40px;-fx-padding:0 0 0 12;-fx-alignment:CENTER_LEFT;";
    }

    private void toggleTheme() {
        isDarkMode = !isDarkMode;
        modeToggleBtn.setText(isDarkMode ? "LIGHT MODE" : "DARK MODE");

        FadeTransition out = new FadeTransition(Duration.millis(160), mainContent);
        out.setFromValue(1.0);
        out.setToValue(0.0);
        out.setOnFinished(ev -> {
            root.setStyle("-fx-background-color: " + bg() + ";");

            blob3.setFill(new RadialGradient(0, 0, 0.5, 0.5, 0.5, true,
                    CycleMethod.NO_CYCLE,
                    new Stop(0, Color.web(D_ACCENT, isDarkMode ? 0.58 : 0.50)),
                    new Stop(1, Color.TRANSPARENT)));
            meshTimer.stop();
            meshStartNano = -1;
            meshTimer.start();

            atmBody.setStyle(glassPanel());
            funcPanel.setStyle(glassPanel());
            inputField.setStyle(inputStyle());
            resultArea.setStyle(resultStyle());

            update();

            FadeTransition in = new FadeTransition(Duration.millis(200), mainContent);
            in.setFromValue(0.0);
            in.setToValue(1.0);
            in.play();
        });
        out.play();
    }

    private String msgStyle(String colour) {
        return "-fx-text-fill:" + colour + ";-fx-font-family:'Courier New';-fx-font-size:13px;-fx-font-weight:bold;-fx-wrap-text:true;";
    }

    private String inputStyle() {
        return "-fx-background-color:rgba(255,255,255,0.05);-fx-text-fill:" + AMBER + ";-fx-font-family:'Courier New';-fx-font-size:20px;-fx-font-weight:bold;-fx-border-color:rgba(255,191,101,0.20);-fx-border-radius:7;-fx-background-radius:7;-fx-border-width:1.2;-fx-padding:6 10 6 10;";
    }

    private String resultStyle() {
        return "-fx-background-color:transparent;-fx-control-inner-background:transparent;-fx-text-fill:#003A6C;-fx-font-family:'Courier New';-fx-font-size:12px;-fx-border-color:transparent;-fx-border-width:0;-fx-focus-color:transparent;-fx-faint-focus-color:transparent;";
    }

    public void setKeyboardInputEnabled(boolean enable) {
        inputField.setEditable(enable);
        if (enable) {
            inputField.setPromptText("Use KEYBOARD to type password...");
            inputField.requestFocus();
        } else {
            inputField.setEditable(false);
            inputField.setPromptText("Enter number...");
        }
    }

    public void update() {
        String msg = uiModel.getMessage();
        String msgLower = msg.toLowerCase();

        String colour;
        if (msgLower.contains("fail") || msgLower.contains("error") || msgLower.contains("lock") ||
                msgLower.contains("incorrect") || msgLower.contains("invalid") || msgLower.contains("denied") ||
                msgLower.contains("too long") || msgLower.contains("attempt") || msgLower.contains("not found")) {
            colour = CORAL;
        } else if (msgLower.contains("success") || msgLower.contains("welcome") || msgLower.contains("applied") ||
                msgLower.contains("changed") || msgLower.contains("deposited") || msgLower.contains("withdrawn") ||
                msgLower.contains("transfer") || msgLower.contains("interest") || msgLower.contains("cleared")) {
            colour = AMBER;
        } else {
            colour = D_TXT2;
        }

        messageLabel.setText(msg);
        messageLabel.setStyle(msgStyle(colour));

        String state = uiModel.getState();
        String rawInput = uiModel.getNumberPadInput();
        boolean masked = state.equals(uiModel.getStatePassword()) || state.equals(uiModel.getStateChPass());

        if (uiModel.isKeyboardInputEnabled()) {
            inputField.setText(rawInput);
        } else {
            inputField.setText(masked && !rawInput.isEmpty() ? "\u25CF".repeat(rawInput.length()) : rawInput);
        }

        resultArea.setText(uiModel.getResult());
        resultArea.setScrollTop(0);

        if (uiModel.isLoggedIn()) {
            accountTypeBadge.setText(uiModel.getAccountTypeDisplay());
            accountTypeBadge.setVisible(true);
        } else {
            accountTypeBadge.setVisible(false);
        }

        stateLabel.setText("State: " + state);

        if (!goodbyeShowing && (msgLower.contains("thank you") || msgLower.contains("goodbye"))) {
            showGoodbyeScreen();
        }
    }
}