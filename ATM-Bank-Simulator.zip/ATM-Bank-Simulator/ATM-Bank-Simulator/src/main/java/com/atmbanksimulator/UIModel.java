package com.atmbanksimulator;

public class UIModel {

    View view;
    private Bank bank;

    private final String STATE_ACCOUNT_NO = "account_no";
    private final String STATE_PASSWORD = "password";
    private final String STATE_LOGGED_IN = "logged_in";
    private final String STATE_CH_PASS = "change_password";
    private final String STATE_TRANSFER_ACC = "transfer_acc";
    private final String STATE_TRANSFER_AMT = "transfer_amt";
    private final String STATE_MINI_STMT = "mini_stmt";
    private final String STATE_CURRENCY = "currency_amt";
    private final String STATE_CURRENCY_SEL = "currency_sel";
    private final String STATE_INTEREST = "interest";
    private final String STATE_CREATE_ACC = "create_account";

    private String state = STATE_ACCOUNT_NO;
    private String accNumber = "";
    private String accPasswd = "";
    private String oldPasswd = "";
    private String message = "";
    private String numberPadInput = "";
    private String result = "";
    private String transferTargetAcc = "";
    private String selectedCurrency = "";

    private int createStep = 1;
    private String newAccNumber = "";
    private String newAccPassword = "";
    private String newAccType = "";
    private boolean confirmLargeTransaction = false;
    private boolean keyboardInputEnabled = false;

    public UIModel(Bank bank) {
        this.bank = bank;
    }

    public void setKeyboardInputEnabled(boolean enable) {
        this.keyboardInputEnabled = enable;
        if (view != null) {
            view.setKeyboardInputEnabled(enable);
        }
    }

    public boolean isKeyboardInputEnabled() {
        return keyboardInputEnabled;
    }

    public void initialise() {
        setState(STATE_ACCOUNT_NO);
        numberPadInput = "";
        message = "Welcome to FIN Bank ATM";
        result = "Please enter your account number, then press Ent.";
        update();
    }

    private void reset(String msg) {
        setState(STATE_ACCOUNT_NO);
        numberPadInput = "";
        message = msg;
        result = "Please enter your account number, then press Ent.";
    }

    private void setState(String newState) {
        if (!state.equals(newState)) {
            String oldState = state;
            state = newState;
            System.out.println("UIModel::setState: changed state from " + oldState + " to " + newState);
        }
    }

    public void processNumber(String numberOnButton) {
        if (keyboardInputEnabled) {
            numberPadInput += numberOnButton;
            message = "";
            result = "";
            update();
            return;
        }

        if (numberPadInput.length() < 8) {
            numberPadInput += numberOnButton;
            message = "";
            result = "";
        } else {
            message = "Input too long!";
            result = "Maximum 8 digits allowed.";
        }
        update();
    }

    public void processClear() {
        numberPadInput = "";
        message = "Cleared.";
        result = "";
        update();
    }

    public void processEnter() {
        if (state.equals(STATE_ACCOUNT_NO)) {
            if (numberPadInput.isEmpty()) {
                message = "Please enter your account number.";
            } else {
                accNumber = numberPadInput;
                numberPadInput = "";
                setState(STATE_PASSWORD);
                message = "Account: " + accNumber;
                result = "Enter your PIN / password, then press Ent.";
            }
        } else if (state.equals(STATE_PASSWORD)) {
            if (numberPadInput.isEmpty()) {
                message = "Please enter your password.";
            } else {
                accPasswd = numberPadInput;
                numberPadInput = "";
                boolean success = bank.login(accNumber, accPasswd);
                if (success) {
                    BankAccount acc = bank.getLoggedInAccount();
                    setState(STATE_LOGGED_IN);
                    message = "Welcome! (" + acc.getAccountTypeName() + " Account)";
                    result = buildLoggedInMenu();
                } else {
                    if (bank.isAccountLocked(accNumber)) {
                        setState(STATE_ACCOUNT_NO);
                        message = "Account LOCKED for 5 minutes.";
                        result = "Too many failed attempts.\nPlease try again later.";
                    } else {
                        int remaining = bank.getRemainingLoginAttempts(accNumber);
                        setState(STATE_ACCOUNT_NO);
                        if (remaining == 1) {
                            message = "WARNING: Last attempt before account LOCKED!";
                            result = "Attempts remaining: " + remaining + "\nEnter account number:";
                        } else {
                            message = "Incorrect password.";
                            result = "Attempts remaining: " + remaining + "\nEnter account number:";
                        }
                    }
                }
            }
        } else if (state.equals(STATE_LOGGED_IN)) {
            if (!numberPadInput.isEmpty()) {
                message = "Select an action first.";
                result = buildLoggedInMenu();
                numberPadInput = "";
            } else {
                message = "Select an option from the menu on the right.";
                result = buildLoggedInMenu();
            }
        } else if (state.equals(STATE_CH_PASS)) {
            if (numberPadInput.isEmpty()) {
                message = "Enter old password.";
                result = "Type your CURRENT password,\nthen press Ent.";
            } else {
                if (oldPasswd.isEmpty()) {
                    oldPasswd = numberPadInput;
                    numberPadInput = "";
                    message = "Enter NEW password (min 4 digits)";
                    result = "Type new password using number pad,\nthen press Ent.";
                } else {
                    String newPass = numberPadInput;
                    numberPadInput = "";
                    boolean changed = bank.changePassword(oldPasswd, newPass);
                    oldPasswd = "";
                    if (changed) {
                        setState(STATE_LOGGED_IN);
                        message = "Password changed!";
                        result = buildLoggedInMenu();
                    } else {
                        setState(STATE_LOGGED_IN);
                        message = "Password change failed.";
                        result = "Old password incorrect.\n\n" + buildLoggedInMenu();
                    }
                }
            }
        } else if (state.equals(STATE_TRANSFER_ACC)) {
            if (numberPadInput.isEmpty()) {
                message = "Enter recipient's account number.";
            } else {
                transferTargetAcc = numberPadInput;
                numberPadInput = "";
                setState(STATE_TRANSFER_AMT);
                message = "Recipient: " + transferTargetAcc;
                result = "Enter amount to transfer, then press Ent.";
            }
        } else if (state.equals(STATE_TRANSFER_AMT)) {
            if (numberPadInput.isEmpty()) {
                message = "Enter amount to transfer.";
            } else {
                try {
                    int amount = Integer.parseInt(numberPadInput);
                    numberPadInput = "";
                    boolean success = bank.transfer(transferTargetAcc, amount);
                    transferTargetAcc = "";
                    setState(STATE_LOGGED_IN);
                    if (success) {
                        message = "Transfer successful!";
                        result = "Transferred £" + amount + "\nNew balance: £" + bank.getBalance() + "\n\n" + buildLoggedInMenu();
                    } else {
                        message = "Transfer failed.";
                        result = "Account not found or insufficient funds.\n\n" + buildLoggedInMenu();
                    }
                } catch (NumberFormatException e) {
                    message = "Invalid amount.";
                    result = "Please enter numbers only.";
                    numberPadInput = "";
                }
            }
        } else if (state.equals(STATE_CURRENCY_SEL)) {
            if (numberPadInput.isEmpty()) {
                message = "Enter a currency number (1-5).";
            } else {
                String[] currencies = {"USD", "EUR", "JPY", "AED", "CAD"};
                try {
                    int choice = Integer.parseInt(numberPadInput);
                    numberPadInput = "";
                    if (choice >= 1 && choice <= currencies.length) {
                        selectedCurrency = currencies[choice - 1];
                        setState(STATE_CURRENCY);
                        message = "Converting to: " + selectedCurrency;
                        result = "Enter GBP amount to convert, then press Ent.";
                    } else {
                        message = "Invalid choice. Enter 1-5.";
                        result = buildCurrencyMenu();
                    }
                } catch (NumberFormatException e) {
                    numberPadInput = "";
                    message = "Enter a number (1-5).";
                    result = buildCurrencyMenu();
                }
            }
        } else if (state.equals(STATE_CURRENCY)) {
            if (numberPadInput.isEmpty()) {
                message = "Enter amount in GBP.";
            } else {
                try {
                    int gbpAmount = Integer.parseInt(numberPadInput);
                    numberPadInput = "";
                    String convResult = bank.convertCurrency(gbpAmount, selectedCurrency);
                    selectedCurrency = "";
                    setState(STATE_LOGGED_IN);
                    message = "Currency Exchange Result";
                    result = convResult + "\n\n" + buildLoggedInMenu();
                } catch (NumberFormatException e) {
                    numberPadInput = "";
                    message = "Invalid amount. Enter numbers only.";
                }
            }
        } else if (state.equals(STATE_INTEREST)) {
            BankAccount acc = bank.getLoggedInAccount();
            if (acc instanceof SavingAccount) {
                SavingAccount saving = (SavingAccount) acc;
                int balanceBefore = saving.getBalance();
                saving.addInterest();
                int balanceAfter = saving.getBalance();
                int earned = balanceAfter - balanceBefore;
                setState(STATE_LOGGED_IN);
                message = "Interest applied!";
                result = "Interest earned: £" + earned + "\nNew balance: £" + balanceAfter + "\n\n" + buildLoggedInMenu();
            } else {
                setState(STATE_LOGGED_IN);
                message = "Not a Savings Account.";
                result = buildLoggedInMenu();
            }
        } else if (state.equals(STATE_CREATE_ACC)) {
            if (createStep == 1) {
                if (numberPadInput.length() < 5) {
                    message = "Account number must be at least 5 digits";
                } else {
                    newAccNumber = numberPadInput;
                    createStep = 2;
                    numberPadInput = "";
                    setKeyboardInputEnabled(true);
                    message = "Step 2/4: Create password (min 4 characters)\nUse KEYBOARD to type";
                    result = "Type password using physical keyboard,\nthen press Ent.";
                }
            } else if (createStep == 2) {
                if (numberPadInput.length() < 4) {
                    message = "Password must be at least 4 characters";
                } else {
                    newAccPassword = numberPadInput;
                    createStep = 3;
                    numberPadInput = "";
                    setKeyboardInputEnabled(false);
                    message = "Step 3/4: Select account type\n1=STANDARD 2=STUDENT 3=PRIME 4=SAVING";
                    result = "";
                }
            } else if (createStep == 3) {
                switch (numberPadInput) {
                    case "1": newAccType = "STANDARD"; break;
                    case "2": newAccType = "STUDENT"; break;
                    case "3": newAccType = "PRIME"; break;
                    case "4": newAccType = "SAVING"; break;
                    default: newAccType = "STANDARD"; break;
                }
                createStep = 4;
                numberPadInput = "";
                message = "Step 4/4: Enter initial deposit (£)";
                result = "Minimum £10";
            } else if (createStep == 4) {
                try {
                    int balance = Integer.parseInt(numberPadInput);
                    if (balance < 10) {
                        message = "Minimum deposit is £10";
                    } else {
                        Bank.AccountType type = Bank.AccountType.valueOf(newAccType);
                        boolean success = bank.createAccount(newAccNumber, newAccPassword, type, balance);
                        if (success) {
                            setState(STATE_ACCOUNT_NO);
                            message = "Account created successfully!";
                            result = "You can now log in with your new account.\nEnter account number:";
                        } else {
                            message = "Account number already exists!";
                            result = "Please try again with a different number.";
                        }
                        numberPadInput = "";
                        createStep = 1;
                        update();
                        return;
                    }
                } catch (NumberFormatException e) {
                    message = "Invalid amount";
                }
                numberPadInput = "";
            }
            update();
            return;
        }
        update();
    }

    public void processWithdraw() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        if (numberPadInput.isEmpty()) {
            message = "Enter amount, then W/D";
            result = "Type the amount to withdraw then press W/D again.";
            confirmLargeTransaction = false;
        } else {
            try {
                int amount = Integer.parseInt(numberPadInput);
                if (amount > 500 && !confirmLargeTransaction) {
                    message = "Large withdrawal: £" + amount;
                    result = "Press W/D again to confirm";
                    confirmLargeTransaction = true;
                    numberPadInput = "";
                    update();
                    return;
                }
                confirmLargeTransaction = false;
                numberPadInput = "";
                boolean success = bank.withdraw(amount);
                if (success) {
                    message = "Withdrawn: £" + amount;
                    result = "New balance: £" + bank.getBalance() + "\n\n" + buildLoggedInMenu();
                } else {
                    message = "Withdrawal failed.";
                    result = "Insufficient funds.\nBalance: £" + bank.getBalance() + "\n\n" + buildLoggedInMenu();
                }
            } catch (NumberFormatException e) {
                message = "Invalid amount.";
                result = "Please enter numbers only.\n\n" + buildLoggedInMenu();
                numberPadInput = "";
            }
        }
        update();
    }

    public void processDeposit() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        if (numberPadInput.isEmpty()) {
            message = "Enter amount, then Dep";
            result = "Type the amount to deposit then press Dep again.";
        } else {
            try {
                int amount = Integer.parseInt(numberPadInput);
                numberPadInput = "";
                boolean success = bank.deposit(amount);
                if (success) {
                    message = "Deposited: £" + amount;
                    result = "New balance: £" + bank.getBalance() + "\n\n" + buildLoggedInMenu();
                } else {
                    message = "Deposit failed.";
                    result = "Invalid amount.\n\n" + buildLoggedInMenu();
                }
            } catch (NumberFormatException e) {
                message = "Invalid amount.";
                result = "Please enter numbers only.\n\n" + buildLoggedInMenu();
                numberPadInput = "";
            }
        }
        update();
    }

    public void processBalance() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        BankAccount acc = bank.getLoggedInAccount();
        message = "Current Balance";
        result = "Last login: " + acc.getLastLoginTime() + "\nBalance: £" + bank.getBalance() + "\n\n" + buildLoggedInMenu();
        update();
    }

    public void processTransfer() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        setState(STATE_TRANSFER_ACC);
        numberPadInput = "";
        transferTargetAcc = "";
        message = "Transfer Money";
        result = "Enter the recipient's account number, then press Ent.";
        update();
    }

    public void processChP() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        setState(STATE_CH_PASS);
        numberPadInput = "";
        oldPasswd = "";
        message = "Change Password";
        result = "Enter your CURRENT password,\nthen press Ent.";
        update();
    }

    public void processMiniStmt() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        setState(STATE_MINI_STMT);
        numberPadInput = "";
        BankAccount acc = bank.getLoggedInAccount();
        message = "Mini Statement";
        result = acc.getMiniStatement();
        update();
    }

    public void processCurrency() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        setState(STATE_CURRENCY_SEL);
        numberPadInput = "";
        selectedCurrency = "";
        message = "Currency Exchange";
        result = buildCurrencyMenu();
        update();
    }

    public void processInterest() {
        if (!bank.loggedIn()) { reset("Not logged in."); update(); return; }
        BankAccount acc = bank.getLoggedInAccount();
        if (acc instanceof SavingAccount) {
            setState(STATE_INTEREST);
            numberPadInput = "";
            message = "Apply Interest";
            result = ((SavingAccount) acc).getInterestPreview();
        } else {
            message = "Not available.";
            result = "Interest is only available for Savings Accounts.\n\n" + buildLoggedInMenu();
        }
        update();
    }

    public void processCreateAccount() {
        if (bank.loggedIn()) {
            message = "Please log out first (press FIN)";
            result = "You must be logged out to create a new account.";
            update();
            return;
        }
        setState(STATE_CREATE_ACC);
        createStep = 1;
        numberPadInput = "";
        message = "CREATE NEW ACCOUNT";
        result = "Step 1/4: Enter new account number (5-8 digits)\nThen press Ent";
        update();
    }

    public void processFinish() {
        setKeyboardInputEnabled(false);
        bank.logout();
        reset("Thank you for using FIN Bank ATM.");
        update();
    }

    public void processUnknownKey(String action) {
        message = "Unknown action: " + action;
        result = "";
        update();
    }

    private void update() {
        view.update();
    }

    private String buildLoggedInMenu() {
        BankAccount acc = bank.getLoggedInAccount();
        String type = (acc != null) ? acc.getAccountTypeName() : "";
        return "──────────────────────\nBAL  Check Balance\nW/D  Withdraw\nDEP  Deposit\nTRF  Transfer\nChP  Change Password\nSTMT Mini Statement\nCUR  Currency Exchange\n" + (type.equals("SAVING") ? "INT  Apply Interest\n" : "") + "FIN  Log Out\n──────────────────────";
    }

    private String buildCurrencyMenu() {
        return "Select target currency:\n1 → USD (US Dollar)\n2 → EUR (Euro)\n3 → JPY (Japanese Yen)\n4 → AED (UAE Dirham)\n5 → CAD (Canadian Dollar)\n\nEnter number (1-5), then Ent.";
    }

    public String getMessage() { return message; }
    public String getNumberPadInput() { return numberPadInput; }
    public String getResult() { return result; }
    public String getState() { return state; }
    public String getAccountTypeDisplay() {
        if (bank.loggedIn()) {
            BankAccount acc = bank.getLoggedInAccount();
            return acc != null ? acc.getAccountTypeName() : "";
        }
        return "";
    }
    public boolean isLoggedIn() { return bank.loggedIn(); }
    public String getStatePassword() { return STATE_PASSWORD; }
    public String getStateChPass() { return STATE_CH_PASS; }
}