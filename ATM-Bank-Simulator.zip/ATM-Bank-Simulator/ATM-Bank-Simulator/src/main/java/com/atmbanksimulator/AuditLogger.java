/**
 * Logs all sensitive actions to audit.log file.
 * Records login attempts, account creation, and locks.
 *
 * @author Reema
 */
package com.atmbanksimulator;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class AuditLogger {
    private static final String LOG_FILE = "audit.log";

    public static void log(String event, String accountNumber) {
        try (PrintWriter out = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            out.println(LocalDateTime.now() + " | " + accountNumber + " | " + event);
        } catch (IOException e) {
            System.err.println("Audit log error: " + e.getMessage());
        }
    }
}