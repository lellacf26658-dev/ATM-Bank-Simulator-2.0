/**
 * Main bank class that manages accounts.
 * Handles login, transfer, currency exchange, and account locking.
 *
 * @author Daniella / Reema (Create Account, Auto-Save, Lock)
 */
package com.atmbanksimulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.time.LocalDateTime;

public class Bank implements java.io.Serializable {

    public enum AccountType {
        STANDARD, STUDENT, PRIME, SAVING
    }

    private ArrayList<BankAccount> accounts = new ArrayList<>();
    private BankAccount loggedInAccount = null;
    private HashMap<String, Integer> loginAttempts = new HashMap<>();
    private HashSet<String> lockedAccounts = new HashSet<>();
    private HashMap<String, LocalDateTime> lockedUntil = new HashMap<>();
    private static final int MAX_LOGIN_ATTEMPTS = 3;
    private static final int LOCK_DURATION_MINUTES = 5;

    private static final Map<String, Double> EXCHANGE_RATES = new HashMap<>();
    static {
        EXCHANGE_RATES.put("USD", 1.27);
        EXCHANGE_RATES.put("EUR", 1.17);
        EXCHANGE_RATES.put("JPY", 191.5);
        EXCHANGE_RATES.put("AED", 4.66);
        EXCHANGE_RATES.put("CAD", 1.73);
    }

    public BankAccount makeBankAccount(String accNumber, String accPasswd, int balance) {
        return new BankAccount(accNumber, accPasswd, balance);
    }

    public BankAccount makeBankAccount(String accNumber, String accPasswd, int balance, AccountType type) {
        switch (type) {
            case STUDENT: return new StudentAccount(accNumber, accPasswd, balance);
            case PRIME:   return new PrimeAccount(accNumber, accPasswd, balance);
            case SAVING:  return new SavingAccount(accNumber, accPasswd, balance);
            default:      return new BankAccount(accNumber, accPasswd, balance);
        }
    }

    public boolean addBankAccount(BankAccount a) {
        accounts.add(a);
        autoSave();
        return true;
    }

    public boolean addBankAccount(String accNumber, String accPasswd, int balance) {
        return addBankAccount(makeBankAccount(accNumber, accPasswd, balance));
    }

    public boolean addBankAccount(String accNumber, String accPasswd, int balance, AccountType type) {
        return addBankAccount(makeBankAccount(accNumber, accPasswd, balance, type));
    }

    private void autoSave() {
        DataManager.saveBank(this);
    }

    public ArrayList<BankAccount> getAllAccounts() {
        return accounts;
    }

    public boolean createAccount(String accNumber, String password, AccountType type, int initialBalance) {
        for (BankAccount acc : accounts) {
            if (acc.getAccNumber().equals(accNumber)) {
                AuditLogger.log("CREATE_ACCOUNT_FAILED_EXISTS", accNumber);
                return false;
            }
        }

        // Allow any password with at least 4 characters
        if (password.length() < 4) {
            AuditLogger.log("CREATE_ACCOUNT_FAILED_WEAK_PASSWORD", accNumber);
            return false;
        }

        BankAccount newAccount = makeBankAccount(accNumber, password, initialBalance, type);
        accounts.add(newAccount);
        autoSave();
        AuditLogger.log("CREATE_ACCOUNT_SUCCESS", accNumber);
        return true;
    }

    public boolean login(String accountNumber, String password) {
        logout();

        if (lockedUntil.containsKey(accountNumber)) {
            if (LocalDateTime.now().isBefore(lockedUntil.get(accountNumber))) {
                AuditLogger.log("LOGIN_ATTEMPT_LOCKED", accountNumber);
                return false;
            } else {
                lockedUntil.remove(accountNumber);
                loginAttempts.put(accountNumber, 0);
            }
        }

        if (lockedAccounts.contains(accountNumber)) {
            return false;
        }

        for (BankAccount b : accounts) {
            if (b.getAccNumber().equals(accountNumber) && b.getaccPasswd().equals(password)) {
                loggedInAccount = b;
                loginAttempts.put(accountNumber, 0);
                b.setLastLoginTime(LocalDateTime.now().toString());
                AuditLogger.log("LOGIN_SUCCESS", accountNumber);
                autoSave();
                return true;
            }
        }

        int attempts = loginAttempts.getOrDefault(accountNumber, 0) + 1;
        loginAttempts.put(accountNumber, attempts);
        AuditLogger.log("LOGIN_FAILED", accountNumber);

        if (attempts >= MAX_LOGIN_ATTEMPTS) {
            lockedUntil.put(accountNumber, LocalDateTime.now().plusMinutes(LOCK_DURATION_MINUTES));
            AuditLogger.log("ACCOUNT_TEMPORARILY_LOCKED", accountNumber);
        }

        loggedInAccount = null;
        return false;
    }

    public void logout() {
        if (loggedIn()) {
            loggedInAccount = null;
        }
    }

    public boolean loggedIn() {
        return loggedInAccount != null;
    }

    public boolean deposit(int amount) {
        if (loggedIn()) {
            boolean result = loggedInAccount.deposit(amount);
            if (result) autoSave();
            return result;
        }
        return false;
    }

    public boolean withdraw(int amount) {
        if (loggedIn()) {
            if (lockedAccounts.contains(loggedInAccount.getAccNumber())) {
                return false;
            }
            boolean result = loggedInAccount.withdraw(amount);
            if (result) autoSave();
            return result;
        }
        return false;
    }

    public int getBalance() {
        if (loggedIn()) {
            return loggedInAccount.getBalance();
        }
        return -1;
    }

    public boolean transfer(String targetAccountNumber, int amount) {
        if (!loggedIn()) return false;

        BankAccount target = null;
        for (BankAccount acc : accounts) {
            if (acc.getAccNumber().equals(targetAccountNumber)) {
                target = acc;
                break;
            }
        }

        if (target == null || target == loggedInAccount) return false;

        if (loggedInAccount.withdraw(amount)) {
            target.deposit(amount);
            autoSave();
            return true;
        }
        return false;
    }

    public boolean changePassword(String old, String newP) {
        if (loggedIn()) {
            boolean result = loggedInAccount.changePassword(old, newP);
            if (result) autoSave();
            return result;
        }
        return false;
    }

    public BankAccount getLoggedInAccount() {
        return loggedInAccount;
    }

    public boolean isAccountLocked(String accountNumber) {
        return lockedAccounts.contains(accountNumber) ||
                (lockedUntil.containsKey(accountNumber) &&
                        LocalDateTime.now().isBefore(lockedUntil.get(accountNumber)));
    }

    public int getRemainingLoginAttempts(String accountNumber) {
        int used = loginAttempts.getOrDefault(accountNumber, 0);
        return Math.max(0, MAX_LOGIN_ATTEMPTS - used);
    }

    public String convertCurrency(int gbpAmount, String currency) {
        String cur = currency.toUpperCase().trim();
        if (!EXCHANGE_RATES.containsKey(cur)) {
            return "Currency '" + cur + "' not supported.\nSupported: " + getAvailableCurrencies();
        }
        double rate = EXCHANGE_RATES.get(cur);
        double result = gbpAmount * rate;
        String resultStr = cur.equals("JPY") ? String.format("%.0f", result) : String.format("%.2f", result);
        return String.format("=== CURRENCY EXCHANGE ===\nAmount: GBP £%d\nRate: 1 GBP = %.4f %s\nResult: %s %s\n========================", gbpAmount, rate, cur, resultStr, cur);
    }

    public String getAvailableCurrencies() {
        return String.join(", ", EXCHANGE_RATES.keySet());
    }
}